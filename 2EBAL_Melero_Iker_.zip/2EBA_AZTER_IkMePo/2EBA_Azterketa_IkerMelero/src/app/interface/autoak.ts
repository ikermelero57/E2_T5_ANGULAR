export interface Autoak {
  id:  number;
  marka:      string;
  modeloa:  string;
}
